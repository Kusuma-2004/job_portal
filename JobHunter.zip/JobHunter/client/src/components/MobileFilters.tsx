import { useEffect, useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";

interface MobileFiltersProps {
  isOpen: boolean;
  onClose: () => void;
  currentFilters: {
    datePosted: string;
    jobType: string[];
    experienceLevel: string[];
    salaryRange: string;
  };
  onFilterChange: (filters: any) => void;
}

const MobileFilters = ({ 
  isOpen, 
  onClose, 
  currentFilters, 
  onFilterChange 
}: MobileFiltersProps) => {
  // Local state for filters
  const [datePosted, setDatePosted] = useState(currentFilters.datePosted || "all");
  const [jobType, setJobType] = useState<string[]>(currentFilters.jobType || []);
  const [experienceLevel, setExperienceLevel] = useState<string[]>(currentFilters.experienceLevel || []);
  const [salaryRange, setSalaryRange] = useState(currentFilters.salaryRange || "");

  useEffect(() => {
    // Update local state when props change
    setDatePosted(currentFilters.datePosted || "all");
    setJobType(currentFilters.jobType || []);
    setExperienceLevel(currentFilters.experienceLevel || []);
    setSalaryRange(currentFilters.salaryRange || "");
  }, [currentFilters]);

  // Reset filters
  const handleReset = () => {
    setDatePosted("all");
    setJobType([]);
    setExperienceLevel([]);
    setSalaryRange("");
  };

  // Apply filters
  const handleApply = () => {
    onFilterChange({
      datePosted,
      jobType,
      experienceLevel,
      salaryRange
    });
    onClose();
  };

  // Handle Job Type change
  const handleJobTypeChange = (value: string, checked: boolean) => {
    setJobType(prev => 
      checked 
        ? [...prev, value] 
        : prev.filter(type => type !== value)
    );
  };

  // Handle Experience Level change
  const handleExperienceLevelChange = (value: string, checked: boolean) => {
    setExperienceLevel(prev => 
      checked 
        ? [...prev, value] 
        : prev.filter(level => level !== value)
    );
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="w-[300px] sm:w-[400px]">
        <SheetHeader>
          <SheetTitle>Filters</SheetTitle>
          <SheetDescription>
            Refine your job search with these filters
          </SheetDescription>
        </SheetHeader>
        
        <div className="py-4 space-y-6">
          {/* Date Posted Filter */}
          <div>
            <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Date Posted</h4>
            <RadioGroup value={datePosted} onValueChange={setDatePosted}>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="last24h" id="m-date-24h" />
                  <Label htmlFor="m-date-24h" className="text-sm text-gray-700">Last 24 hours</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="last3d" id="m-date-3d" />
                  <Label htmlFor="m-date-3d" className="text-sm text-gray-700">Last 3 days</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="last7d" id="m-date-7d" />
                  <Label htmlFor="m-date-7d" className="text-sm text-gray-700">Last 7 days</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="last14d" id="m-date-14d" />
                  <Label htmlFor="m-date-14d" className="text-sm text-gray-700">Last 14 days</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="m-date-all" />
                  <Label htmlFor="m-date-all" className="text-sm text-gray-700">All</Label>
                </div>
              </div>
            </RadioGroup>
          </div>
          
          <Separator />
          
          {/* Job Type Filter */}
          <div>
            <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Job Type</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-job-type-fulltime" 
                  checked={jobType.includes('full-time')}
                  onCheckedChange={(checked) => 
                    handleJobTypeChange('full-time', checked as boolean)
                  }
                />
                <Label htmlFor="m-job-type-fulltime" className="text-sm text-gray-700">Full-time</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-job-type-parttime" 
                  checked={jobType.includes('part-time')}
                  onCheckedChange={(checked) => 
                    handleJobTypeChange('part-time', checked as boolean)
                  }
                />
                <Label htmlFor="m-job-type-parttime" className="text-sm text-gray-700">Part-time</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-job-type-contract" 
                  checked={jobType.includes('contract')}
                  onCheckedChange={(checked) => 
                    handleJobTypeChange('contract', checked as boolean)
                  }
                />
                <Label htmlFor="m-job-type-contract" className="text-sm text-gray-700">Contract</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-job-type-temporary" 
                  checked={jobType.includes('temporary')}
                  onCheckedChange={(checked) => 
                    handleJobTypeChange('temporary', checked as boolean)
                  }
                />
                <Label htmlFor="m-job-type-temporary" className="text-sm text-gray-700">Temporary</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-job-type-internship" 
                  checked={jobType.includes('internship')}
                  onCheckedChange={(checked) => 
                    handleJobTypeChange('internship', checked as boolean)
                  }
                />
                <Label htmlFor="m-job-type-internship" className="text-sm text-gray-700">Internship</Label>
              </div>
            </div>
          </div>
          
          <Separator />
          
          {/* Experience Level Filter */}
          <div>
            <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Experience Level</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-exp-entry" 
                  checked={experienceLevel.includes('entry')}
                  onCheckedChange={(checked) => 
                    handleExperienceLevelChange('entry', checked as boolean)
                  }
                />
                <Label htmlFor="m-exp-entry" className="text-sm text-gray-700">Entry Level</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-exp-mid" 
                  checked={experienceLevel.includes('mid')}
                  onCheckedChange={(checked) => 
                    handleExperienceLevelChange('mid', checked as boolean)
                  }
                />
                <Label htmlFor="m-exp-mid" className="text-sm text-gray-700">Mid Level</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="m-exp-senior" 
                  checked={experienceLevel.includes('senior')}
                  onCheckedChange={(checked) => 
                    handleExperienceLevelChange('senior', checked as boolean)
                  }
                />
                <Label htmlFor="m-exp-senior" className="text-sm text-gray-700">Senior Level</Label>
              </div>
            </div>
          </div>
          
          <Separator />
          
          {/* Salary Range Filter */}
          <div>
            <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Salary Range</h4>
            <RadioGroup value={salaryRange} onValueChange={setSalaryRange}>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="$30,000+" id="m-salary-30k" />
                  <Label htmlFor="m-salary-30k" className="text-sm text-gray-700">$30,000+</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="$50,000+" id="m-salary-50k" />
                  <Label htmlFor="m-salary-50k" className="text-sm text-gray-700">$50,000+</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="$70,000+" id="m-salary-70k" />
                  <Label htmlFor="m-salary-70k" className="text-sm text-gray-700">$70,000+</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="$90,000+" id="m-salary-90k" />
                  <Label htmlFor="m-salary-90k" className="text-sm text-gray-700">$90,000+</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="$110,000+" id="m-salary-110k" />
                  <Label htmlFor="m-salary-110k" className="text-sm text-gray-700">$110,000+</Label>
                </div>
              </div>
            </RadioGroup>
          </div>
        </div>
        
        <SheetFooter className="flex justify-between sm:justify-between mt-4">
          <Button variant="outline" onClick={handleReset}>
            Reset
          </Button>
          <Button onClick={handleApply}>
            Apply Filters
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
};

export default MobileFilters;
