import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";

const EmployerCTA = () => {
  return (
    <section className="bg-primary py-16">
      <div className="container mx-auto px-4">
        <div className="lg:flex lg:items-center lg:justify-between">
          <div className="lg:w-1/2 mb-8 lg:mb-0">
            <h2 className="text-3xl font-bold text-white mb-4">Hire top talent for your team</h2>
            <p className="text-blue-100 text-lg mb-6">
              Connect with qualified candidates and build your dream team. Post your job listing today and reach thousands of job seekers.
            </p>
            <Link href="/post-job">
              <Button variant="secondary" className="bg-white text-primary hover:bg-gray-100">
                Post a Job
              </Button>
            </Link>
          </div>
          
          <div className="lg:w-1/2">
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-4">Why employers choose us</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <div className="flex-shrink-0">
                    <CheckCircle className="text-green-500 h-5 w-5 mt-0.5" />
                  </div>
                  <p className="ml-3 text-gray-700">Access to a large pool of qualified candidates</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0">
                    <CheckCircle className="text-green-500 h-5 w-5 mt-0.5" />
                  </div>
                  <p className="ml-3 text-gray-700">Easy-to-use dashboard to manage applications</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0">
                    <CheckCircle className="text-green-500 h-5 w-5 mt-0.5" />
                  </div>
                  <p className="ml-3 text-gray-700">Targeted job promotion to reach relevant candidates</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0">
                    <CheckCircle className="text-green-500 h-5 w-5 mt-0.5" />
                  </div>
                  <p className="ml-3 text-gray-700">Detailed analytics and reporting tools</p>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EmployerCTA;
