import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

interface FiltersSidebarProps {
  currentFilters: {
    datePosted: string;
    jobType: string[];
    experienceLevel: string[];
    salaryRange: string;
  };
  onFilterChange: (filters: any) => void;
}

const FiltersSidebar = ({ currentFilters, onFilterChange }: FiltersSidebarProps) => {
  const [datePosted, setDatePosted] = useState(currentFilters.datePosted || "all");
  const [jobType, setJobType] = useState<string[]>(currentFilters.jobType || []);
  const [experienceLevel, setExperienceLevel] = useState<string[]>(currentFilters.experienceLevel || []);
  const [salaryRange, setSalaryRange] = useState(currentFilters.salaryRange || "");

  useEffect(() => {
    // Update local state when props change
    setDatePosted(currentFilters.datePosted || "all");
    setJobType(currentFilters.jobType || []);
    setExperienceLevel(currentFilters.experienceLevel || []);
    setSalaryRange(currentFilters.salaryRange || "");
  }, [currentFilters]);

  // Handle Date Posted change
  const handleDatePostedChange = (value: string) => {
    setDatePosted(value);
    onFilterChange({
      ...currentFilters,
      datePosted: value
    });
  };

  // Handle Job Type change
  const handleJobTypeChange = (value: string, checked: boolean) => {
    const updatedJobTypes = checked 
      ? [...jobType, value] 
      : jobType.filter(type => type !== value);
    
    setJobType(updatedJobTypes);
    onFilterChange({
      ...currentFilters,
      jobType: updatedJobTypes
    });
  };

  // Handle Experience Level change
  const handleExperienceLevelChange = (value: string, checked: boolean) => {
    const updatedExperienceLevels = checked 
      ? [...experienceLevel, value] 
      : experienceLevel.filter(level => level !== value);
    
    setExperienceLevel(updatedExperienceLevels);
    onFilterChange({
      ...currentFilters,
      experienceLevel: updatedExperienceLevels
    });
  };

  // Handle Salary Range change
  const handleSalaryRangeChange = (value: string) => {
    setSalaryRange(value);
    onFilterChange({
      ...currentFilters,
      salaryRange: value
    });
  };

  return (
    <Card className="bg-white rounded-lg shadow p-5 sticky top-24">
      <h3 className="font-semibold text-lg mb-4">Filters</h3>
      
      {/* Date Posted Filter */}
      <div className="mb-6">
        <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Date Posted</h4>
        <RadioGroup value={datePosted} onValueChange={handleDatePostedChange}>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="last24h" id="date-24h" />
              <Label htmlFor="date-24h" className="text-sm text-gray-700">Last 24 hours</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="last3d" id="date-3d" />
              <Label htmlFor="date-3d" className="text-sm text-gray-700">Last 3 days</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="last7d" id="date-7d" />
              <Label htmlFor="date-7d" className="text-sm text-gray-700">Last 7 days</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="last14d" id="date-14d" />
              <Label htmlFor="date-14d" className="text-sm text-gray-700">Last 14 days</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="all" id="date-all" />
              <Label htmlFor="date-all" className="text-sm text-gray-700">All</Label>
            </div>
          </div>
        </RadioGroup>
      </div>
      
      {/* Job Type Filter */}
      <div className="mb-6">
        <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Job Type</h4>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="job-type-fulltime" 
              checked={jobType.includes('full-time')}
              onCheckedChange={(checked) => 
                handleJobTypeChange('full-time', checked as boolean)
              }
            />
            <Label htmlFor="job-type-fulltime" className="text-sm text-gray-700">Full-time</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="job-type-parttime" 
              checked={jobType.includes('part-time')}
              onCheckedChange={(checked) => 
                handleJobTypeChange('part-time', checked as boolean)
              }
            />
            <Label htmlFor="job-type-parttime" className="text-sm text-gray-700">Part-time</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="job-type-contract" 
              checked={jobType.includes('contract')}
              onCheckedChange={(checked) => 
                handleJobTypeChange('contract', checked as boolean)
              }
            />
            <Label htmlFor="job-type-contract" className="text-sm text-gray-700">Contract</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="job-type-temporary" 
              checked={jobType.includes('temporary')}
              onCheckedChange={(checked) => 
                handleJobTypeChange('temporary', checked as boolean)
              }
            />
            <Label htmlFor="job-type-temporary" className="text-sm text-gray-700">Temporary</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="job-type-internship" 
              checked={jobType.includes('internship')}
              onCheckedChange={(checked) => 
                handleJobTypeChange('internship', checked as boolean)
              }
            />
            <Label htmlFor="job-type-internship" className="text-sm text-gray-700">Internship</Label>
          </div>
        </div>
      </div>
      
      {/* Experience Level Filter */}
      <div className="mb-6">
        <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Experience Level</h4>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="exp-entry" 
              checked={experienceLevel.includes('entry')}
              onCheckedChange={(checked) => 
                handleExperienceLevelChange('entry', checked as boolean)
              }
            />
            <Label htmlFor="exp-entry" className="text-sm text-gray-700">Entry Level</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="exp-mid" 
              checked={experienceLevel.includes('mid')}
              onCheckedChange={(checked) => 
                handleExperienceLevelChange('mid', checked as boolean)
              }
            />
            <Label htmlFor="exp-mid" className="text-sm text-gray-700">Mid Level</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="exp-senior" 
              checked={experienceLevel.includes('senior')}
              onCheckedChange={(checked) => 
                handleExperienceLevelChange('senior', checked as boolean)
              }
            />
            <Label htmlFor="exp-senior" className="text-sm text-gray-700">Senior Level</Label>
          </div>
        </div>
      </div>
      
      {/* Salary Range Filter */}
      <div>
        <h4 className="font-medium text-sm uppercase text-gray-500 mb-3">Salary Range</h4>
        <RadioGroup value={salaryRange} onValueChange={handleSalaryRangeChange}>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="$30,000+" id="salary-30k" />
              <Label htmlFor="salary-30k" className="text-sm text-gray-700">$30,000+</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="$50,000+" id="salary-50k" />
              <Label htmlFor="salary-50k" className="text-sm text-gray-700">$50,000+</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="$70,000+" id="salary-70k" />
              <Label htmlFor="salary-70k" className="text-sm text-gray-700">$70,000+</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="$90,000+" id="salary-90k" />
              <Label htmlFor="salary-90k" className="text-sm text-gray-700">$90,000+</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="$110,000+" id="salary-110k" />
              <Label htmlFor="salary-110k" className="text-sm text-gray-700">$110,000+</Label>
            </div>
          </div>
        </RadioGroup>
      </div>
    </Card>
  );
};

export default FiltersSidebar;
