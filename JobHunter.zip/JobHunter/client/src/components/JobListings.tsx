import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import JobCard from "./JobCard";
import FiltersSidebar from "./FiltersSidebar";
import MobileFilters from "./MobileFilters";
import { Job } from "@shared/schema";
import { ChevronLeft, ChevronRight } from "lucide-react";

const JobListings = () => {
  // Get URL search params
  const [, setLocation] = useLocation();
  const search = useSearch();
  const searchParams = new URLSearchParams(search);
  
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortBy, setSortBy] = useState("relevance");
  const jobsPerPage = 10;

  // Get filters from URL
  const searchTerm = searchParams.get("search") || "";
  const locationFilter = searchParams.get("location") || "";
  const categoryFilter = searchParams.get("category") || "";
  const jobTypeFilter = searchParams.get("jobType")?.split(",") || [];
  const experienceLevelFilter = searchParams.get("experienceLevel")?.split(",") || [];
  const datePostedFilter = searchParams.get("datePosted") || "all";
  const salaryRangeFilter = searchParams.get("salaryRange") || "";

  // Fetch jobs with filters
  const { data: jobs, isLoading, error } = useQuery<Job[]>({
    queryKey: [
      `/api/jobs?search=${searchTerm}&location=${locationFilter}&category=${categoryFilter}&jobType=${jobTypeFilter.join(",")}&experienceLevel=${experienceLevelFilter.join(",")}&datePosted=${datePostedFilter}&salaryRange=${salaryRangeFilter}`
    ]
  });

  const toggleFilters = () => {
    setFiltersOpen(!filtersOpen);
  };

  const handleFilterChange = (filters: any) => {
    // Update URL with new filters
    const params = new URLSearchParams(search);
    
    // Reset to page 1 when filters change
    setCurrentPage(1);
    
    // Update search params
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== "all" && value.length > 0) {
        if (Array.isArray(value)) {
          params.set(key, (value as string[]).join(","));
        } else {
          params.set(key, value as string);
        }
      } else {
        params.delete(key);
      }
    });
    
    setLocation(`/jobs?${params.toString()}`);
  };

  // Pagination logic
  const totalJobs = jobs?.length || 0;
  const totalPages = Math.ceil(totalJobs / jobsPerPage);
  const indexOfLastJob = currentPage * jobsPerPage;
  const indexOfFirstJob = indexOfLastJob - jobsPerPage;
  const currentJobs = jobs?.slice(indexOfFirstJob, indexOfLastJob) || [];

  const renderPagination = () => {
    if (totalPages <= 1) return null;

    return (
      <div className="mt-6 flex items-center justify-between bg-white px-4 py-3 rounded-lg shadow sm:px-6">
        <div className="flex flex-1 justify-between sm:hidden">
          <Button
            variant="outline"
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            Next
          </Button>
        </div>
        <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-gray-700">
              Showing <span className="font-medium">{indexOfFirstJob + 1}</span> to{" "}
              <span className="font-medium">
                {Math.min(indexOfLastJob, totalJobs)}
              </span>{" "}
              of <span className="font-medium">{totalJobs}</span> results
            </p>
          </div>
          <div>
            <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
              <Button
                variant="outline"
                className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <span className="sr-only">Previous</span>
                <ChevronLeft className="h-5 w-5" />
              </Button>

              {/* Generate page numbers */}
              {[...Array(Math.min(totalPages, 5))].map((_, i) => {
                const pageNumber = i + 1;
                const isCurrentPage = pageNumber === currentPage;
                
                return (
                  <Button
                    key={pageNumber}
                    variant={isCurrentPage ? "default" : "outline"}
                    className={`relative inline-flex items-center px-4 py-2 text-sm font-semibold ${
                      isCurrentPage 
                        ? "bg-primary text-white focus:z-20" 
                        : "text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                    }`}
                    onClick={() => setCurrentPage(pageNumber)}
                  >
                    {pageNumber}
                  </Button>
                );
              })}

              {/* Show "..." if there are more pages */}
              {totalPages > 5 && (
                <>
                  <span className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-700 ring-1 ring-inset ring-gray-300 focus:outline-offset-0">
                    ...
                  </span>
                  <Button
                    variant="outline"
                    className="relative hidden items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 md:inline-flex"
                    onClick={() => setCurrentPage(totalPages)}
                  >
                    {totalPages}
                  </Button>
                </>
              )}

              <Button
                variant="outline"
                className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <span className="sr-only">Next</span>
                <ChevronRight className="h-5 w-5" />
              </Button>
            </nav>
          </div>
        </div>
      </div>
    );
  };

  return (
    <section className="py-8 md:py-12">
      <div className="container mx-auto px-4">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          {/* Filters Sidebar */}
          <div className="hidden lg:block lg:col-span-3">
            <FiltersSidebar 
              currentFilters={{
                datePosted: datePostedFilter,
                jobType: jobTypeFilter,
                experienceLevel: experienceLevelFilter,
                salaryRange: salaryRangeFilter
              }}
              onFilterChange={handleFilterChange}
            />
          </div>
          
          {/* Mobile Filters */}
          <MobileFilters 
            isOpen={filtersOpen}
            onClose={() => setFiltersOpen(false)}
            currentFilters={{
              datePosted: datePostedFilter,
              jobType: jobTypeFilter,
              experienceLevel: experienceLevelFilter,
              salaryRange: salaryRangeFilter
            }}
            onFilterChange={handleFilterChange}
          />
          
          {/* Job Listings */}
          <div className="lg:col-span-9 mt-6 lg:mt-0">
            <Card className="mb-6 p-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <h2 className="font-semibold text-xl mb-3 sm:mb-0">
                  {isLoading 
                    ? <Skeleton className="h-7 w-32" /> 
                    : `${totalJobs} jobs found`
                  }
                </h2>
                <div className="flex items-center">
                  <label htmlFor="sort-by" className="text-sm text-gray-700 mr-2">Sort by:</label>
                  <select 
                    id="sort-by" 
                    className="text-sm border border-gray-300 rounded p-1 focus:ring-primary focus:border-primary"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                  >
                    <option value="relevance">Relevance</option>
                    <option value="date">Date</option>
                    <option value="salary">Salary</option>
                  </select>
                </div>
              </div>
            </Card>
            
            {/* Mobile Filters Button */}
            <div className="lg:hidden mb-4">
              <Button 
                variant="outline" 
                className="w-full bg-white"
                onClick={toggleFilters}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-4 w-4"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
                Filters
              </Button>
            </div>
            
            {/* Job List */}
            <div className="space-y-4">
              {isLoading ? (
                // Loading skeletons
                Array.from({ length: 5 }).map((_, i) => (
                  <Card key={i} className="p-5">
                    <div className="flex flex-col space-y-3">
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-16 w-full" />
                      <div className="flex flex-wrap gap-2">
                        <Skeleton className="h-6 w-16 rounded-full" />
                        <Skeleton className="h-6 w-20 rounded-full" />
                        <Skeleton className="h-6 w-16 rounded-full" />
                      </div>
                    </div>
                  </Card>
                ))
              ) : error ? (
                <Card className="p-5">
                  <div className="text-center text-red-500">
                    Failed to load jobs. Please try again later.
                  </div>
                </Card>
              ) : currentJobs.length === 0 ? (
                <Card className="p-5">
                  <div className="text-center text-gray-500">
                    No jobs found matching your criteria. Try adjusting your filters.
                  </div>
                </Card>
              ) : (
                currentJobs.map(job => (
                  <JobCard key={job.id} job={job} />
                ))
              )}
              
              {/* Pagination */}
              {renderPagination()}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JobListings;
