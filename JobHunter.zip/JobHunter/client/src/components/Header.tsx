import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

const Header = () => {
  const [location] = useLocation();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-3 md:mb-0">
          <Link href="/">
            <a className="text-primary font-bold text-2xl">
              CareerConnect
            </a>
          </Link>
        </div>
        
        <nav className="w-full md:w-auto">
          <ul className="flex flex-wrap justify-center gap-1 md:gap-2">
            <li>
              <Link href="/jobs">
                <a className={`inline-block px-3 py-2 font-medium text-sm hover:bg-blue-50 rounded ${location === "/jobs" ? "text-primary" : "text-gray-700"}`}>
                  Find Jobs
                </a>
              </Link>
            </li>
            <li>
              <a href="#" className="inline-block px-3 py-2 text-gray-700 font-medium text-sm hover:bg-blue-50 rounded">
                Companies
              </a>
            </li>
            <li>
              <a href="#" className="inline-block px-3 py-2 text-gray-700 font-medium text-sm hover:bg-blue-50 rounded">
                Resources
              </a>
            </li>
            <li className="w-full md:w-auto mt-2 md:mt-0 md:ml-2">
              <Link href="/post-job">
                <a className={`inline-block w-full md:w-auto px-4 py-2 border border-primary font-medium text-sm rounded hover:bg-blue-50 text-center ${location === "/post-job" ? "bg-blue-50 text-primary" : "bg-transparent text-primary"}`}>
                  Post a Job
                </a>
              </Link>
            </li>
            <li className="w-full md:w-auto mt-2 md:mt-0 md:ml-2">
              <Link href="/profile">
                <Button variant="default" className="w-full md:w-auto">Sign In</Button>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
