import { useState, FormEvent } from "react";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SearchIcon, MapPinIcon } from "lucide-react";

const HeroSearch = () => {
  const [, setLocation] = useLocation();
  const [keywords, setKeywords] = useState("");
  const [locationInput, setLocationInput] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    
    const searchParams = new URLSearchParams();
    if (keywords) searchParams.append("search", keywords);
    if (locationInput) searchParams.append("location", locationInput);
    
    setLocation(`/jobs?${searchParams.toString()}`);
  };

  return (
    <section className="bg-primary text-white py-10 md:py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl md:text-4xl font-bold mb-6 text-center">Find Your Next Career Opportunity</h1>
          
          <div className="bg-white rounded-lg p-4 shadow-lg">
            <form className="grid grid-cols-1 md:grid-cols-12 gap-4" onSubmit={handleSubmit}>
              <div className="md:col-span-5">
                <label htmlFor="keywords" className="block text-gray-700 text-sm font-medium mb-1">What</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon className="h-4 w-4 text-gray-400" />
                  </div>
                  <Input 
                    type="text" 
                    id="keywords" 
                    placeholder="Job title, keywords, or company" 
                    className="pl-10"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="md:col-span-5">
                <label htmlFor="location" className="block text-gray-700 text-sm font-medium mb-1">Where</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPinIcon className="h-4 w-4 text-gray-400" />
                  </div>
                  <Input 
                    type="text" 
                    id="location" 
                    placeholder="City, state, or remote" 
                    className="pl-10"
                    value={locationInput}
                    onChange={(e) => setLocationInput(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="md:col-span-2 flex items-end">
                <Button 
                  type="submit" 
                  className="w-full bg-primary text-white"
                >
                  Search
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSearch;
