import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Category } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const CategoryIcon = ({ icon }: { icon: string }) => {
  return (
    <div className="h-12 w-12 bg-blue-100 text-primary rounded-full flex items-center justify-center mb-3">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-xl"
      >
        {icon === 'fa-laptop-code' && (
          <>
            <rect x="4" y="5" width="16" height="14" rx="2" />
            <line x1="12" y1="14" x2="12" y2="14" />
            <line x1="8" y1="19" x2="16" y2="19" />
          </>
        )}
        {icon === 'fa-chart-line' && (
          <>
            <line x1="18" y1="20" x2="18" y2="10" />
            <line x1="12" y1="20" x2="12" y2="4" />
            <line x1="6" y1="20" x2="6" y2="14" />
          </>
        )}
        {icon === 'fa-paint-brush' && (
          <>
            <path d="M18 3v4c0 2-2 3-4 3H8c-2 0-4-1-4-3V3" />
            <path d="M10 17v4" />
            <path d="M14 17v4" />
            <path d="M7 11v6" />
            <path d="M17 11v6" />
          </>
        )}
        {icon === 'fa-bullhorn' && (
          <>
            <path d="M3 10v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2Z" />
            <path d="M17 16v2a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2v-2" />
            <path d="M21 16V8a2 2 0 0 0-2-2h-2" />
            <path d="M3 16V8a2 2 0 0 1 2-2h2" />
          </>
        )}
        {icon === 'fa-heartbeat' && (
          <>
            <path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z" />
            <path d="M3.5 12h6l.5-1 1.5 3 2-5 1.5 3h5.5" />
          </>
        )}
        {icon === 'fa-graduation-cap' && (
          <>
            <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
            <path d="M6 12v5c3 3 9 3 12 0v-5" />
          </>
        )}
        {icon === 'fa-gavel' && (
          <>
            <path d="m14 14-8.5 8.5c-.83.83-2.17.83-3 0 0 0 0 0 0 0a2.12 2.12 0 0 1 0-3L11 11" />
            <path d="M16 16 11 11" />
            <path d="m5 7 5 5" />
            <path d="m19 3-5 5" />
            <path d="M20.5 14.5 16 10l4-4 4.5 4.5a2.13 2.13 0 1 1-3 3Z" />
            <path d="m4 8 4.5-4.5a2.13 2.13 0 1 1 3 3L7 11" />
          </>
        )}
        {icon === 'fa-utensils' && (
          <>
            <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" />
            <path d="M7 2v20" />
            <path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Z" />
            <path d="M18 22V15" />
          </>
        )}
      </svg>
    </div>
  );
};

const CategorySection = () => {
  const { data: categories, isLoading, error } = useQuery<Category[]>({
    queryKey: ['/api/categories']
  });

  if (error) {
    return (
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 text-center text-red-500">
          Failed to load categories
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-10 text-center">Browse Jobs by Category</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {isLoading ? (
            // Loading skeletons
            Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-5 text-center">
                <div className="flex flex-col items-center">
                  <Skeleton className="h-12 w-12 rounded-full mb-3" />
                  <Skeleton className="h-5 w-24 mb-1" />
                  <Skeleton className="h-4 w-16" />
                </div>
              </div>
            ))
          ) : (
            categories?.map((category) => (
              <Link 
                key={category.id} 
                href={`/jobs?category=${encodeURIComponent(category.name)}`}
              >
                <a className="border border-gray-200 rounded-lg p-5 text-center hover:border-primary hover:shadow-md transition-all">
                  <div className="flex flex-col items-center">
                    <CategoryIcon icon={category.icon} />
                    <h3 className="font-medium mb-1">{category.name}</h3>
                    <p className="text-sm text-gray-500">{category.jobCount} jobs</p>
                  </div>
                </a>
              </Link>
            ))
          )}
        </div>
        
        <div className="mt-10 text-center">
          <Link href="/jobs">
            <a className="text-primary font-medium hover:text-blue-700">
              View All Categories 
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="16" 
                height="16" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="ml-1 inline"
              >
                <line x1="5" y1="12" x2="19" y2="12"></line>
                <polyline points="12 5 19 12 12 19"></polyline>
              </svg>
            </a>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
