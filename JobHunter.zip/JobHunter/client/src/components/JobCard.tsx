import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { BookmarkIcon, Share2Icon } from "lucide-react";
import ApplicationModal from "./ApplicationModal";
import { Job } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface JobCardProps {
  job: Job;
}

const JobCard = ({ job }: JobCardProps) => {
  const { toast } = useToast();
  const [isApplicationModalOpen, setIsApplicationModalOpen] = useState(false);

  const handleSaveJob = () => {
    toast({
      title: "Job saved",
      description: "This job has been saved to your profile"
    });
  };

  const handleShareJob = () => {
    // Copy the job URL to clipboard
    navigator.clipboard.writeText(window.location.origin + `/jobs/${job.id}`);
    toast({
      title: "Link copied",
      description: "Job link has been copied to clipboard"
    });
  };

  return (
    <>
      <Card className="hover:shadow-md transition-shadow">
        <div className="p-5">
          <div className="flex items-start">
            <div className="flex-shrink-0 hidden sm:block">
              <div className="h-14 w-14 rounded bg-gray-200 flex items-center justify-center text-gray-500">
                {job.company.substring(0, 1)}
              </div>
            </div>
            <div className="sm:ml-4 flex-1">
              <div className="flex flex-col sm:flex-row sm:justify-between">
                <div>
                  <Link href={`/jobs/${job.id}`}>
                    <h3 className="text-lg font-medium text-primary hover:underline cursor-pointer">
                      {job.title}
                    </h3>
                  </Link>
                  <p className="text-base text-gray-700 font-medium">{job.company}</p>
                  <p className="text-sm text-gray-500">{job.location}</p>
                </div>
                <div className="mt-2 sm:mt-0 flex flex-col items-start sm:items-end">
                  {job.salary && (
                    <span className="text-sm font-medium text-green-700">{job.salary}</span>
                  )}
                  <span className="text-xs text-gray-500">
                    Posted {formatDistanceToNow(new Date(job.postedDate), { addSuffix: true })}
                  </span>
                </div>
              </div>
              
              <div className="mt-4">
                <p className="text-sm text-gray-600 line-clamp-2">
                  {job.description}
                </p>
              </div>
              
              <div className="mt-4 flex flex-wrap gap-2">
                {job.skills.map((skill, index) => (
                  <Badge key={index} variant="skill">{skill}</Badge>
                ))}
                <Badge variant="jobType">{job.jobType}</Badge>
              </div>
              
              <div className="mt-5 flex flex-col sm:flex-row sm:items-center justify-between">
                <Button 
                  variant="secondary" 
                  className="mb-2 sm:mb-0 w-full sm:w-auto"
                  onClick={() => setIsApplicationModalOpen(true)}
                >
                  Apply Now
                </Button>
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    className="text-gray-500 hover:text-primary flex items-center text-sm"
                    onClick={handleSaveJob}
                  >
                    <BookmarkIcon className="h-4 w-4 mr-1" /> Save
                  </button>
                  <button
                    type="button"
                    className="text-gray-500 hover:text-primary flex items-center text-sm"
                    onClick={handleShareJob}
                  >
                    <Share2Icon className="h-4 w-4 mr-1" /> Share
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <ApplicationModal 
        isOpen={isApplicationModalOpen}
        onClose={() => setIsApplicationModalOpen(false)}
        job={job}
      />
    </>
  );
};

export default JobCard;
