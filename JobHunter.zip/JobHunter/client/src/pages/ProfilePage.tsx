import { useState } from "react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Job, Application } from "@shared/schema";
import { Separator } from "@/components/ui/separator";
import { 
  User, Mail, MapPin, Briefcase, FileText, Edit, 
  ChevronRight, Clock, Building, Award
} from "lucide-react";

const ProfilePage = () => {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  
  // Mock user data - in real app would come from auth/session
  const user = {
    id: 1,
    username: "johndoe",
    email: "john.doe@example.com",
    userType: "jobseeker", // or "employer"
    location: "San Francisco, CA",
    bio: "Experienced software engineer with expertise in frontend development using React, TypeScript, and modern JavaScript frameworks.",
    skills: ["React", "TypeScript", "JavaScript", "Node.js", "CSS"]
  };
  
  // Fetch user's applications
  const { data: applications } = useQuery<Application[]>({
    queryKey: [`/api/users/${user.id}/applications`],
    enabled: user.userType === "jobseeker"
  });
  
  // Fetch jobs posted by employer
  const { data: employerJobs } = useQuery<Job[]>({
    queryKey: [`/api/employers/${user.id}/jobs`],
    enabled: user.userType === "employer"
  });
  
  const handleSaveProfile = () => {
    // Would handle saving profile data to API
    toast({
      title: "Profile updated",
      description: "Your profile changes have been saved."
    });
    setIsEditing(false);
  };

  return (
    <>
      <Helmet>
        <title>My Profile | CareerConnect</title>
        <meta name="description" content="Manage your CareerConnect profile" />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                <Avatar className="w-20 h-20">
                  <AvatarImage src="" alt={user.username} />
                  <AvatarFallback className="text-2xl bg-primary text-white">
                    {user.username.substring(0, 1).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <div>
                      <h1 className="text-2xl font-bold">{user.username}</h1>
                      <div className="flex items-center text-gray-600 mt-1">
                        <Mail className="h-4 w-4 mr-1" />
                        <span>{user.email}</span>
                      </div>
                      <div className="flex items-center text-gray-600 mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{user.location}</span>
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0">
                      <Badge variant="outline" className="capitalize">
                        {user.userType === "jobseeker" ? "Job Seeker" : "Employer"}
                      </Badge>
                    </div>
                  </div>
                  
                  {!isEditing ? (
                    <p className="text-gray-700">{user.bio}</p>
                  ) : (
                    <div className="space-y-4 mt-4">
                      <div>
                        <Label htmlFor="username">Username</Label>
                        <Input id="username" defaultValue={user.username} />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" defaultValue={user.email} />
                      </div>
                      <div>
                        <Label htmlFor="location">Location</Label>
                        <Input id="location" defaultValue={user.location} />
                      </div>
                      <div>
                        <Label htmlFor="bio">Bio</Label>
                        <Textarea id="bio" defaultValue={user.bio} rows={4} />
                      </div>
                      {user.userType === "jobseeker" && (
                        <div>
                          <Label htmlFor="skills">Skills (comma separated)</Label>
                          <Input id="skills" defaultValue={user.skills.join(", ")} />
                        </div>
                      )}
                    </div>
                  )}
                  
                  {!isEditing ? (
                    <Button 
                      onClick={() => setIsEditing(true)} 
                      variant="outline" 
                      className="mt-4"
                      size="sm"
                    >
                      <Edit className="h-4 w-4 mr-2" /> Edit Profile
                    </Button>
                  ) : (
                    <div className="flex gap-2 mt-4">
                      <Button onClick={handleSaveProfile} size="sm">
                        Save Changes
                      </Button>
                      <Button 
                        onClick={() => setIsEditing(false)} 
                        variant="outline" 
                        size="sm"
                      >
                        Cancel
                      </Button>
                    </div>
                  )}
                </div>
              </div>
              
              {user.userType === "jobseeker" && !isEditing && (
                <div className="mt-6">
                  <h3 className="text-sm font-medium text-gray-500 uppercase mb-2">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {user.skills.map((skill, index) => (
                      <Badge key={index} variant="skill">{skill}</Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Tabs defaultValue={user.userType === "jobseeker" ? "applications" : "jobs"}>
            <TabsList className="grid w-full md:w-auto md:inline-flex grid-cols-2 md:grid-cols-none mb-4">
              {user.userType === "jobseeker" ? (
                <>
                  <TabsTrigger value="applications">My Applications</TabsTrigger>
                  <TabsTrigger value="saved">Saved Jobs</TabsTrigger>
                </>
              ) : (
                <>
                  <TabsTrigger value="jobs">Posted Jobs</TabsTrigger>
                  <TabsTrigger value="applications">Applications Received</TabsTrigger>
                </>
              )}
            </TabsList>
            
            {user.userType === "jobseeker" && (
              <>
                <TabsContent value="applications">
                  <Card>
                    <CardHeader>
                      <CardTitle>My Applications</CardTitle>
                      <CardDescription>
                        Track the status of your job applications
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {!applications || applications.length === 0 ? (
                        <div className="text-center py-8">
                          <FileText className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                          <h3 className="text-lg font-medium text-gray-900 mb-1">No applications yet</h3>
                          <p className="text-gray-500">
                            You haven't applied to any jobs yet. Start searching for jobs to apply!
                          </p>
                          <Button className="mt-4" variant="outline" asChild>
                            <a href="/jobs">Browse Jobs</a>
                          </Button>
                        </div>
                      ) : (
                        <div className="divide-y">
                          {applications.map((application) => (
                            <div key={application.id} className="py-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-medium text-lg">{application.name}</h3>
                                  <p className="text-gray-500 text-sm">{application.email}</p>
                                </div>
                                <Badge
                                  className={
                                    application.status === "hired"
                                      ? "bg-green-100 text-green-800"
                                      : application.status === "rejected"
                                      ? "bg-red-100 text-red-800"
                                      : application.status === "interview"
                                      ? "bg-blue-100 text-blue-800"
                                      : "bg-gray-100 text-gray-800"
                                  }
                                >
                                  {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                                </Badge>
                              </div>
                              <p className="mt-2 text-sm text-gray-700">
                                Applied on {new Date(application.appliedDate).toLocaleDateString()}
                              </p>
                              <div className="mt-3 flex items-center justify-end">
                                <Button variant="ghost" size="sm" className="text-primary">
                                  View Details <ChevronRight className="ml-1 h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="saved">
                  <Card>
                    <CardHeader>
                      <CardTitle>Saved Jobs</CardTitle>
                      <CardDescription>
                        Jobs you've saved to apply later
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-8">
                        <Briefcase className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                        <h3 className="text-lg font-medium text-gray-900 mb-1">No saved jobs</h3>
                        <p className="text-gray-500">
                          You haven't saved any jobs yet. Save jobs to apply to them later.
                        </p>
                        <Button className="mt-4" variant="outline" asChild>
                          <a href="/jobs">Browse Jobs</a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </>
            )}
            
            {user.userType === "employer" && (
              <>
                <TabsContent value="jobs">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <div>
                        <CardTitle>Posted Jobs</CardTitle>
                        <CardDescription>
                          Manage your job listings
                        </CardDescription>
                      </div>
                      <Button asChild>
                        <a href="/post-job">Post a New Job</a>
                      </Button>
                    </CardHeader>
                    <CardContent>
                      {!employerJobs || employerJobs.length === 0 ? (
                        <div className="text-center py-8">
                          <Briefcase className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                          <h3 className="text-lg font-medium text-gray-900 mb-1">No jobs posted</h3>
                          <p className="text-gray-500">
                            You haven't posted any jobs yet. Create your first job listing!
                          </p>
                          <Button className="mt-4" asChild>
                            <a href="/post-job">Post a Job</a>
                          </Button>
                        </div>
                      ) : (
                        <div className="divide-y">
                          {employerJobs.map((job) => (
                            <div key={job.id} className="py-4">
                              <div className="flex flex-col md:flex-row md:items-center justify-between">
                                <div>
                                  <h3 className="font-medium text-lg">{job.title}</h3>
                                  <div className="flex flex-wrap gap-2 mt-2">
                                    <div className="flex items-center text-gray-600 text-sm">
                                      <Building className="h-3 w-3 mr-1" />
                                      <span>{job.company}</span>
                                    </div>
                                    <div className="flex items-center text-gray-600 text-sm">
                                      <MapPin className="h-3 w-3 mr-1" />
                                      <span>{job.location}</span>
                                    </div>
                                    <div className="flex items-center text-gray-600 text-sm">
                                      <Clock className="h-3 w-3 mr-1" />
                                      <span>Posted on {new Date(job.postedDate).toLocaleDateString()}</span>
                                    </div>
                                  </div>
                                </div>
                                <div className="mt-3 md:mt-0 flex items-center">
                                  <Button variant="outline" size="sm" className="mr-2">
                                    Edit
                                  </Button>
                                  <Button asChild size="sm">
                                    <a href={`/jobs/${job.id}`}>View</a>
                                  </Button>
                                </div>
                              </div>
                              <div className="mt-3 flex flex-wrap gap-1">
                                <Badge variant="jobType">{job.jobType}</Badge>
                                <Badge variant="outline">
                                  {job.experienceLevel === 'entry' && 'Entry Level'}
                                  {job.experienceLevel === 'mid' && 'Mid Level'}
                                  {job.experienceLevel === 'senior' && 'Senior Level'}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="applications">
                  <Card>
                    <CardHeader>
                      <CardTitle>Applications Received</CardTitle>
                      <CardDescription>
                        Review and manage applications for your job listings
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-8">
                        <User className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                        <h3 className="text-lg font-medium text-gray-900 mb-1">No applications received</h3>
                        <p className="text-gray-500">
                          You haven't received any applications yet. Post more jobs to attract candidates.
                        </p>
                        <Button className="mt-4" asChild>
                          <a href="/post-job">Post a Job</a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </>
            )}
          </Tabs>
        </div>
      </div>
    </>
  );
};

export default ProfilePage;
