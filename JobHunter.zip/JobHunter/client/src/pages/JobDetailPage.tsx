import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, MapPin, Building, Clock, DollarSign, Briefcase, Award } from "lucide-react";
import ApplicationModal from "@/components/ApplicationModal";
import { Job } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

const JobDetailPage = () => {
  const { id } = useParams();
  const jobId = parseInt(id);
  const [isApplicationModalOpen, setIsApplicationModalOpen] = useState(false);

  const { data: job, isLoading, error } = useQuery<Job>({
    queryKey: [`/api/jobs/${jobId}`]
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-8 w-48 mb-6" />
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <Skeleton className="h-10 w-3/4" />
                <div className="flex space-x-2">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-5 w-32" />
                </div>
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-48 w-full" />
                <Skeleton className="h-36 w-full" />
                <div className="flex flex-wrap gap-2">
                  <Skeleton className="h-6 w-16 rounded-full" />
                  <Skeleton className="h-6 w-20 rounded-full" />
                  <Skeleton className="h-6 w-24 rounded-full" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-6 text-center">
              <h1 className="text-xl font-bold text-red-500 mb-2">Error Loading Job</h1>
              <p className="text-gray-600 mb-4">
                We couldn't find the job you're looking for. It may have been removed or does not exist.
              </p>
              <Link href="/jobs">
                <Button>
                  <ChevronLeft className="h-4 w-4 mr-2" /> 
                  Back to Jobs
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Link href="/jobs">
          <Button variant="ghost" className="mb-6">
            <ChevronLeft className="h-4 w-4 mr-2" /> 
            Back to Jobs
          </Button>
        </Link>
        
        <Card>
          <CardContent className="p-6">
            {/* Job Header */}
            <div className="mb-6 border-b pb-6">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-2xl font-bold mb-2">{job.title}</h1>
                  <div className="flex items-center flex-wrap gap-y-2">
                    <div className="flex items-center text-gray-600 mr-4">
                      <Building className="h-4 w-4 mr-1" />
                      <span>{job.company}</span>
                    </div>
                    <div className="flex items-center text-gray-600 mr-4">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>{job.location}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Posted {formatDistanceToNow(new Date(job.postedDate), { addSuffix: true })}</span>
                    </div>
                  </div>
                </div>
                <Button onClick={() => setIsApplicationModalOpen(true)}>
                  Apply Now
                </Button>
              </div>
            </div>
            
            {/* Job Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="flex items-center">
                <Briefcase className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Job Type</p>
                  <p className="font-medium">{job.jobType}</p>
                </div>
              </div>
              {job.salary && (
                <div className="flex items-center">
                  <DollarSign className="h-5 w-5 text-primary mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Salary</p>
                    <p className="font-medium">{job.salary}</p>
                  </div>
                </div>
              )}
              <div className="flex items-center">
                <Award className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Experience</p>
                  <p className="font-medium">
                    {job.experienceLevel === 'entry' && 'Entry Level'}
                    {job.experienceLevel === 'mid' && 'Mid Level'}
                    {job.experienceLevel === 'senior' && 'Senior Level'}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Job Description */}
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-4">Job Description</h2>
              <div className="text-gray-700 whitespace-pre-line">
                {job.description}
              </div>
            </div>
            
            {/* Job Requirements */}
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-4">Requirements</h2>
              <div className="text-gray-700 whitespace-pre-line">
                {job.requirements}
              </div>
            </div>
            
            {/* Skills */}
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-4">Skills</h2>
              <div className="flex flex-wrap gap-2">
                {job.skills.map((skill, index) => (
                  <Badge key={index} variant="skill">{skill}</Badge>
                ))}
              </div>
            </div>
            
            {/* Apply Button */}
            <div className="mt-8 flex justify-center">
              <Button 
                size="lg" 
                onClick={() => setIsApplicationModalOpen(true)}
              >
                Apply for this position
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Application Modal */}
      <ApplicationModal 
        isOpen={isApplicationModalOpen}
        onClose={() => setIsApplicationModalOpen(false)}
        job={job}
      />
    </div>
  );
};

export default JobDetailPage;
