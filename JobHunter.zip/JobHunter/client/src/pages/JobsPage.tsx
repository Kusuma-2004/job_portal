import JobListings from "@/components/JobListings";

const JobsPage = () => {
  return <JobListings />;
};

export default JobsPage;
