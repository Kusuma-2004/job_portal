import { Helmet } from "react-helmet";
import JobForm from "@/components/JobForm";

const PostJobPage = () => {
  return (
    <>
      <Helmet>
        <title>Post a Job | CareerConnect</title>
        <meta name="description" content="Post a new job listing on CareerConnect" />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-3">Post a New Job Listing</h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Reach thousands of qualified candidates by posting your job on CareerConnect. 
              Fill out the form below to create your job listing.
            </p>
          </div>
          
          <JobForm />
        </div>
      </div>
    </>
  );
};

export default PostJobPage;
