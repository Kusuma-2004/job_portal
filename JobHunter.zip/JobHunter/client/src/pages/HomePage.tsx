import HeroSearch from "@/components/HeroSearch";
import CategorySection from "@/components/CategorySection";
import EmployerCTA from "@/components/EmployerCTA";
import { useQuery } from "@tanstack/react-query";
import { Job } from "@shared/schema";
import JobCard from "@/components/JobCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const HomePage = () => {
  // Fetch featured jobs (most recent 5 jobs)
  const { data: featuredJobs, isLoading } = useQuery<Job[]>({
    queryKey: ['/api/jobs'],
  });

  return (
    <>
      <HeroSearch />
      
      {/* Featured Jobs Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Featured Jobs</h2>
            <Link href="/jobs">
              <Button variant="outline">
                View All Jobs
              </Button>
            </Link>
          </div>
          
          <div className="space-y-4">
            {isLoading ? (
              // Loading skeletons
              Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="p-5">
                  <div className="flex flex-col space-y-3">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-4 w-1/3" />
                    <Skeleton className="h-16 w-full" />
                    <div className="flex flex-wrap gap-2">
                      <Skeleton className="h-6 w-16 rounded-full" />
                      <Skeleton className="h-6 w-20 rounded-full" />
                      <Skeleton className="h-6 w-16 rounded-full" />
                    </div>
                  </div>
                </Card>
              ))
            ) : !featuredJobs || featuredJobs.length === 0 ? (
              <Card className="p-5">
                <div className="text-center text-gray-500">
                  No featured jobs available at the moment.
                </div>
              </Card>
            ) : (
              // Display most recent 3 jobs
              featuredJobs.slice(0, 3).map(job => (
                <JobCard key={job.id} job={job} />
              ))
            )}
          </div>
        </div>
      </section>
      
      <CategorySection />
      <EmployerCTA />
    </>
  );
};

export default HomePage;
